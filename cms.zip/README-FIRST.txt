Hi,

Please read the documentation for the installation and update process.

tnx.
Best regards