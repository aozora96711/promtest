<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        Powered by MangaReader CMS v2.0
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; {{ date('Y') }} <a href="#">CyberWorks</a>.</strong>
</footer>