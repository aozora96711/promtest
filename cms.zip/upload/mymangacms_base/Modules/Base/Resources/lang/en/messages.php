<?php

return [
    /** Admin **/
    'admin.permission_denied'                   => 'permission denied',
    'admin.modules'                             => 'Modules',
    
    /** Front **/

];
