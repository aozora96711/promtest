<?php

view()->creator(
    [
        'base::admin._partials.sidebar',
    ],
    'Modules\Base\Composers\SidebarViewCreatorComposer'
);
