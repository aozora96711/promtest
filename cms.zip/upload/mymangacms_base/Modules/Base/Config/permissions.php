<?php

return [
    'dashboard' => [
        'index' => 'View Dashboard',
    ],
    'settings' => [
        'edit_general' => 'Edit All Settings',
        'edit_themes' => 'Edit Themes Options',
    ],
];
