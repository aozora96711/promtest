<?php

return [
    'no notifications' => 'There are no notifications.',
    'notifications' => 'Notifications',
    'delete all confirmation' => 'Are you sure you want to delete all notifications ?',
    'time' => 'Time',
    'title' => 'Title',
    'message' => 'Message',
    'is read' => 'Is read',
    'mark all as read' => 'Mark all as read',
    'delete all' => 'Delete all',
    'all notifications deleted' => 'All your notifications were successfully deleted.',
    'all notifications marked as read' => 'All your notifications were successfully marked as read.',
    'view all' => 'View all',
    'notification settings' => 'Notification settings',
    'notification.modal.tips' => 'This is the configuration of the notifications displayed on website header, it has no relation with email notifications.',
    'notification.modal.msg' =>  'Notify me on new creation of:',
];
