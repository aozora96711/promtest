<?php

return [
    'name' => 'Manga'
];
