<?php

return [
    'name' => 'Ads'
];
