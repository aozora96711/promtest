<?php

view()->composer(
    [
        '*',
    ],
    'Modules\User\Composers\ConnectedUserViewComposer'
);
