<?php

return [
    'name' => 'MySpace'
];
