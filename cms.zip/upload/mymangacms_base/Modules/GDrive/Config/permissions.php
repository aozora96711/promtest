<?php

return [
    'gdrive' => [
        'manage_gdrive' => 'Manage GDrive',
    ],
];
